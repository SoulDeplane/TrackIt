/*
Main JavaScript File
Handles role-based login redirection
UI Prototype Only (No backend authentication)
*/

document.addEventListener("DOMContentLoaded", function () {

    const loginForm = document.querySelector("form");

    if (loginForm) {
        loginForm.addEventListener("submit", function (event) {
            event.preventDefault(); // Prevent page reload

            const roleDropdown = document.querySelector("select");
            const selectedRole = roleDropdown.value;

            if (selectedRole === "Student") {
                window.location.href = "student-dashboard.html";
            } 
            else if (selectedRole === "Parent") {
                window.location.href = "parent-dashboard.html";
            } 
            else if (selectedRole === "Driver") {
                window.location.href = "driver-dashboard.html";
            } 
            else if (selectedRole === "Admin") {
                window.location.href = "admin-dashboard.html";
            } 
            else {
                alert("Please select a role before logging in.");
            }
        });
    }

});